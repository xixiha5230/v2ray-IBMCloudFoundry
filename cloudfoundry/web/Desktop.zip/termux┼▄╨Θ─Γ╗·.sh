qemu-system-aarch64 \
  -machine virt -m 512M -cpu cortex-a57 \
  -smp 1 \
  -kernel vmlinuz-lts -initrd initramfs-lts \
  -append "quiet,console=ttyAMA0 modules=loop,squashfs,sd-mod,usb-storage ip=dhcp alpine_repo=http://dl-cdn.alpinelinux.org/alpine/edge/main/" \
  -hda virt-alpine.img \
  -nographic

qemu-system-aarch64 \
  -machine virt -m 512M -cpu cortex-a57 \
  -smp 1 \
  -kernel linux -initrd initrd \
  -append "quiet,console=ttyAMA0 modules=loop,squashfs,sd-mod,usb-storage ip=dhcp" \
  -hda debian.img \
  -nographic

qemu-system-aarch64 -hda debian.img -boot c -m 512 -netdev user,id=nde1,hostfwd=tcp::2222-:22 -device e1000,netdev=nde1,id=d-net1 -nographic

#download "vmlinuz-lts" and "initramfs-lts" from http://dl-cdn.alpinelinux.org/alpine/edge/releases/aarch64/netboot/