#start frp
cd /root/frp
bash frps -c frps.ini &

#close all screen
screen -ls | grep '(Detached)' | awk '{print $1}' | xargs -I % -t screen -X -S % quit

#start mirai
cd /root/mirai
screen -dmS qq
screen -x -S qq -p 0 -X stuff "java -jar cqhttp-mirai-0.2.3-embedded-all.jar"
screen -x -S qq -p 0 -X stuff $'\n'
sleep 5
screen -x -S qq -p 0 -X stuff "login 1156998117 XixihaPaswd_qq."
screen -x -S qq -p 0 -X stuff $'\n'

#start ehforwarderbot
sleep 30
cd /root
screen -dmS efb
screen -x -S efb -p 0 -X stuff "ehforwarderbot"
screen -x -S efb -p 0 -X stuff $'\n'

#restart mirai
sleep 60
cd /root/mirai
screen -x -S qq -p 0 -X stuff $'\003'
sleep 5
screen -x -S qq -p 0 -X stuff "java -jar cqhttp-mirai-0.2.3-embedded-all.jar"
screen -x -S qq -p 0 -X stuff $'\n'
sleep 5
screen -x -S qq -p 0 -X stuff "login 1156998117 XixihaPaswd_qq."
screen -x -S qq -p 0 -X stuff $'\n'